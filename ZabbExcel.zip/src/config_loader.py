import os
import configparser

from paths import LOGS_DIR, REPORTS_DIR

SAMPLE_CONFIG = """
[JumpServers]
username = root
password = 9898
A2E = 192.168.1.61
DSO = 192.168.1.62
# ... add more

[ZabbixEndpoints]
A2E = https://192.168.1.60.com/api_jsonrpc.php
DSO = https://192.168.1.62.com/api_jsonrpc.php
# ... add more

[Email]
sender = your@email.com
recipients = recipient1@email.com,recipient2@email.com

[General]
report_folder = reports
log_folder = logs

[ZabbixCredentials]
username = zabbix_user
password = zabbix_pass
"""

def load_config():
    # Always resolve config path relative to project root
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    config_path = os.path.join(base_dir, "config", "config.ini")
    if not os.path.exists(config_path):
        print(f"Config file not found at {config_path}. Creating a sample config.")
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        with open(config_path, "w") as f:
            f.write(SAMPLE_CONFIG.strip())
        print("Please edit the config file and re-run the app.")
        exit(1)
    config = configparser.ConfigParser()
    config.read(config_path)
    return config