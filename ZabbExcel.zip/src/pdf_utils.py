import fitz  # PyMuPDF
import os

from datetime import datetime
from PIL import Image  # for auto-scaling the logo

LOGO_WIDTH = 80
LOGO_HEIGHT = 30
LOGO_SCALE = 2.5
LOGO_MARGIN_BOTTOM = -12
LOGO_MARGIN_LEFT = 19 
PAGE_NUMBER_MARGIN_BOTTOM = 20
PAGE_NUMBER_MARGIN_RIGHT = 20

def get_scaled_size(image_path, width_pts=None, height_pts=None):
    with Image.open(image_path) as img:
        w, h = img.size  # in pixels
        aspect_ratio = w / h

        if width_pts and not height_pts:
            height_pts = width_pts / aspect_ratio
        elif height_pts and not width_pts:
            width_pts = height_pts * aspect_ratio
        elif not width_pts and not height_pts:
            width_pts = w * 0.75  # Assume 96 DPI → convert to 72 DPI (points)
            height_pts = h * 0.75

        return width_pts, height_pts

def add_logo_footer(
        pdf_path, logo_path, logger=None,
        logo_width=LOGO_WIDTH,
        logo_height=LOGO_HEIGHT,
        scale=LOGO_SCALE,
        margin_bottom=LOGO_MARGIN_BOTTOM,
        margin_left=LOGO_MARGIN_LEFT,
        output_path=None):
    
    if not os.path.exists(logo_path):
        msg = f"Logo file not found: {logo_path}"
        print(msg)
        if logger:
            logger.warning(msg)
        return False

    if output_path is None:
        output_path = pdf_path

    try:
        # Auto-scale the logo if only one dimension is given
        logo_width, logo_height = get_scaled_size(
            logo_path, width_pts=logo_width, height_pts=logo_height
        )
        
        logo_width = float(logo_width or 100.0)
        logo_height = float(logo_height or 50.0)

        logo_width *= scale
        logo_height *= scale

        doc = fitz.open(pdf_path)
        total_pages = doc.page_count

        for i in range(total_pages):
            page = doc[i]
            page_height = page.rect.height
            page_width = page.rect.width

            x = margin_left
            y = page_height - logo_height - margin_bottom

            rect = fitz.Rect(x, y, x + logo_width, y + logo_height)
            page.insert_image(rect, filename=logo_path)     # type: ignore

            # --- Add page number at right footer ---
            page_number_text = f"Page {i+1} of {total_pages}"
            font_size = 9
            text_width = fitz.get_text_length(page_number_text, fontname="cour", fontsize=font_size)
            text_x = page_width - text_width - 19 # 20pt from right edge
            text_y = page_height - PAGE_NUMBER_MARGIN_BOTTOM - 2.5   # 5pt above page edge
            page.insert_text(   # type: ignore
                fitz.Point(text_x, text_y),
                page_number_text,
                fontsize=font_size,
                fontname="cour",
                color=(0, 0, 0),
            )
            solid_text_1 = f"NEC Confidential"
            font_size = 9
            text_width = fitz.get_text_length(solid_text_1, fontname="cour", fontsize=font_size)
            text_x = page_width - text_width - 150  # 20pt from right edge  
            text_y = page_height - PAGE_NUMBER_MARGIN_BOTTOM - 2.5   # 5pt above page edge
            page.insert_text(   # type: ignore
                fitz.Point(text_x, text_y),
                solid_text_1,
                fontsize=font_size,
                fontname="cour",
                color=(0, 0, 0),
            )
            now = datetime.now()
            solid_text_2 = f"Zabbix Monitoring Report {now.strftime('%d-%m-%Y')}"
            font_size = 9
            text_width = fitz.get_text_length(solid_text_2, fontname="cour", fontsize=font_size)
            text_x = page_width - text_width - 310  
            text_y = page_height - PAGE_NUMBER_MARGIN_BOTTOM - 2.5   # 5pt above page edge
            page.insert_text(   # type: ignore
                fitz.Point(text_x, text_y),
                solid_text_2,
                fontsize=font_size,
                fontname="cour",
                color=(0, 0, 0),
            )

        doc.save(output_path)

        if logger:
            logger.info(f"=================================================")
            logger.info(f"Logo added to footer of every page in PDF: {output_path}")
            logger.info(f"=================================================")

        return True

    except Exception as e:
        msg = f"Failed to add logo to PDF: {e}"
        print(msg)
        if logger:
            logger.error(msg)
        return False
