import os
import openpyxl

from datetime import datetime
from paths import LOGS_DIR, REPORTS_DIR
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment

SEVERITY_MAP = {
    "0": "Not classified",
    "1": "Information",
    "2": "Warning",
    "3": "Average",
    "4": "High",
    "5": "Disaster"
}

SEVERITY_SORT_ORDER = {
    "Information": 0,
    "Warning": 1,
    "Average": 2,
    "High": 3,
    "Disaster": 4,
    "Not classified": 5
}

def format_clock(clock):
    try:
        dt = datetime.fromtimestamp(int(clock))
        return dt.strftime("%d/%m/%Y   %H:%M")
    except Exception:
        return ""

def format_age(clock):
    try:
        event_time = datetime.fromtimestamp(int(clock))
        now = datetime.now()
        delta = now - event_time
        days = delta.days
        hours, remainder = divmod(delta.seconds, 3600)
        minutes, _ = divmod(remainder, 60)
        if days > 0:
            return f"{days}d {hours}h"
        elif hours > 0:
            return f"{hours}h {minutes}m"
        else:
            return f"{minutes}m"
    except Exception:
        return ""

# Define a thin border style
thin_border = Border(
    left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin')
)

class ExcelReportGenerator:
    def __init__(self, output_dir=REPORTS_DIR, logger=None):
        self.sheet_names = ["A2E-D", "A2E-C", "DSO-D", "SHD-D", "NAD-D", "BXA-D", "AUQ-D", "DXV-D", "DXP-D"]
        # < incase want excel file to be daynamic from config file, comment above, and uncomment below >
        #self.sheet_names = [name.upper() for name in sheet_names]
        self.headers = ["Site", "Severity", "Status", "Jira", "Last Changes", "Age", "Ack", "Host", "Description"]
        self.logger = logger
        self.output_dir = output_dir
        self.workbook = openpyxl.Workbook()
        self.sheets = {}

    def create_empty_report(self):
        gray_fill = PatternFill(start_color="808080", end_color="808080", fill_type="solid")
        # Remove the default sheet and create the required ones
        default_sheet = self.workbook.active
        if default_sheet is not None:
            self.workbook.remove(default_sheet)
        for name in self.sheet_names:
            ws = self.workbook.create_sheet(title=name)
            # column widths
            ws.column_dimensions['A'].width = 6
            ws.column_dimensions['B'].width = 12
            ws.column_dimensions['C'].width = 8
            ws.column_dimensions['D'].width = 5
            ws.column_dimensions['E'].width = 18.8
            ws.column_dimensions['F'].width = 8
            ws.column_dimensions['G'].width = 4
            ws.column_dimensions['H'].width = 50
            ws.column_dimensions['I'].width = 120
            ws.append(self.headers)
            # Set header styles
            for idx in range(1, len(self.headers) + 1):
                cell = ws.cell(row=1, column=idx)
                cell.font = Font(name="Consolas", size=10, bold=True)
                cell.fill = gray_fill
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="left", vertical="center")
            self.sheets[name] = ws
        if self.logger:
            self.logger.info("Created empty Zabbix report with all sheets and headers.")

    def append_alarms(self, site, alarms):
        sheet_name = site.upper()
        if sheet_name not in self.sheets:
            if self.logger:
                self.logger.error(f"Sheet for site {site.upper()} does not exist.")
            return
        ws = self.sheets[sheet_name]
        for alarm in alarms:
            severity = SEVERITY_MAP.get(str(alarm.get("severity", "")), str(alarm.get("severity", "")))
            clock = alarm.get("clock", "")
            name = alarm.get("name", "")
            hosts = alarm.get("hosts", [])
            host = hosts[0]["host"] if hosts and "host" in hosts[0] else ""
            age = format_age(clock)
            last_changes = format_clock(clock)
            status = alarm.get("Active", "Problem")  # Get status, default to "Problem"

            row = [
                sheet_name.upper(),
                severity,
                status,
                "",  # info
                last_changes,
                age,
                "No",
                host,
                name
            ]
            ws.append(row)
            last_row = ws.max_row
            # Apply styles to the newly added row
            for col in range(1, len(row) + 1):
                cell = ws.cell(row=last_row, column=col)
                # Default font for all cells
                cell.font = Font(name="Consolas", size=10)
                # Font color for columns B, E, G (2, 5, 7)
                if col in (2, 5, 7):
                    cell.font = Font(name="Consolas", size=10, color="00268E")
                if col == 3:
                    #cell.font = Font(name="Consolas", size=10, color="DC0000")
                    if status == "Active":
                        cell.font = Font(name="Consolas", size=10, color="DC0000", bold=True)
                    elif status == "Problem":
                        cell.font = Font(name="Consolas", size=10, color="DC0000")
                # Apply border to all cells
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="left", vertical="center")
        if self.logger:
            self.logger.info(f"Appended {len(alarms)} alarms to sheet {site.upper()}.")

    def save(self):
        now = datetime.now()
        base_filename = f"Zabbix_Monitoring_Report_{now.strftime('%d-%m-%Y')}"
        filename = f"{base_filename}.xlsx"
        output_path = os.path.join(self.output_dir, filename)
        counter = 1
        while os.path.exists(output_path):
            filename = f"{base_filename}_{counter}.xlsx"
            output_path = os.path.join(self.output_dir, filename)
            counter += 1
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        self.workbook.save(output_path)
        if self.logger:
            self.logger.info(f"Excel report saved to {output_path}")
        return output_path