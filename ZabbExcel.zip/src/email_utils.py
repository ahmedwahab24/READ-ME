import os
import smtplib

from email.message import EmailMessage
from paths import LOGS_DIR, REPORTS_DIR

def send_email_with_attachments(
    smtp_server, smtp_port, smtp_user, smtp_password,
    sender, recipients, subject, body, attachment_paths, logger=None
):
    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = recipients if isinstance(recipients, str) else ", ".join(recipients)
    msg["Subject"] = subject
    msg.set_content(body, subtype='html')

    # Attach all files in the list
    for attachment_path in attachment_paths:
        with open(attachment_path, "rb") as f:
            file_data = f.read()
            file_name = os.path.basename(attachment_path)
        msg.add_attachment(file_data, maintype="application", subtype="octet-stream", filename=file_name)

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo()
            smtp.login(smtp_user, smtp_password)
            smtp.send_message(msg)
        if logger:
            logger.info(f"Email sent to {recipients} with attachments {[os.path.basename(p) for p in attachment_paths]}")
        return True
    except Exception as e:
        if logger:
            logger.error(f"Failed to send email: {e}")
        return False