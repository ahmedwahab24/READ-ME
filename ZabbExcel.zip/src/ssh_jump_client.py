import paramiko

from paths import LOGS_DIR, REPORTS_DIR

class SSHJumpClient:
    def __init__(self, hostname, username, password, logger=None):
        self.hostname = hostname
        self.username = username
        self.password = password
        self.client = None
        self.logger = logger

    def connect(self):
        try:
            if self.logger:
                self.logger.info(f"Connecting to Jump IP [{self.hostname}]")
            self.client = paramiko.SSHClient()
            self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.client.connect(self.hostname, username=self.username, password=self.password)
            if self.logger:
                self.logger.info(f"Connected to [{self.hostname}]")
            return True
        except Exception as e:
            if self.logger:
                self.logger.error(f"SSH connection failed: {e}")
            return False

    def disconnect(self):
        if self.client:
            self.client.close()
            if self.logger:
                self.logger.info(f"Disconnected from [{self.hostname}]")

    def run_curl(self, curl_command):
        if not self.client:
            if self.logger:
                self.logger.error("SSH client not connected.")
            return None, "SSH client not connected.", -1
        try:
            stdin, stdout, stderr = self.client.exec_command(curl_command)
            out = stdout.read().decode()
            err = stderr.read().decode()
            exit_status = stdout.channel.recv_exit_status()
            if self.logger:
                if exit_status != 0:
                    self.logger.error(f"Command error: {err}")
            return out, err, exit_status
        except Exception as e:
            if self.logger:
                self.logger.error(f"Failed to execute command: {e}")
                self.logger.info(f"=================================================")
            return None, str(e), -1