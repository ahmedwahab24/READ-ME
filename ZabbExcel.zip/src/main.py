import os
import sys
import getpass
import logging
import smtplib
import datetime

from logging import config
from config_loader import load_config
from ssh_jump_client import SSHJumpClient
from zabbix_api_client import ZabbixAPIClient
from excel_report_generator import ExcelReportGenerator
from email_utils import send_email_with_attachments
from paths import LOGS_DIR, REPORTS_DIR, BASE_DIR
from excel_to_pdf import excel_to_pdf
from pdf_utils import add_logo_footer, LOGO_MARGIN_BOTTOM, LOGO_WIDTH, LOGO_HEIGHT, LOGO_SCALE, LOGO_MARGIN_LEFT

SEVERITY_SORT_ORDER = {
    "Information": 0,
    "Warning": 1,
    "Average": 2,
    "High": 3,
    "Disaster": 4,
    "Not classified": 5
}

SEVERITY_MAP = {
    "0": "Not classified",
    "1": "Information",
    "2": "Warning",
    "3": "Average",
    "4": "High",
    "5": "Disaster"
}

os.makedirs(LOGS_DIR, exist_ok=True)
date_str = datetime.datetime.now().strftime("%d-%m-%Y")
counter = 1
log_file = os.path.join(LOGS_DIR, f"{date_str}_{counter}.log")
while os.path.exists(log_file):
    counter += 1
    log_file = os.path.join(LOGS_DIR, f"{date_str}_{counter}.log")

logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s: %(message)s"
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
formatter = logging.Formatter("%(asctime)s %(levelname)s: %(message)s")
console.setFormatter(formatter)
logging.getLogger().addHandler(console)
logger = logging.getLogger(__name__)

# Print summary to terminal
def build_summary_text(sites, summary_stats):
    summary_lines = []
    for idx, site in enumerate(sites):
        stats = summary_stats.get(site, {})
        site_upper = site.upper()
        is_last = idx == len(sites) - 1
        branch = "└──" if is_last else "├──"
        pipe = "    " if is_last else "│   "
        summary_lines.append(f"{branch} {site_upper}:")
        summary_lines.append(f"{pipe}├── Total Alarms for {site_upper}: {stats.get('total', 0)}")
        summary_lines.append(f"{pipe}├── Total information alarms: {stats.get('Information', 0)}")
        summary_lines.append(f"{pipe}├── Total Warning alarms: {stats.get('Warning', 0)}")
        summary_lines.append(f"{pipe}├── Total Average alarms: {stats.get('Average', 0)}")
        summary_lines.append(f"{pipe}├── Total High alarms: {stats.get('High', 0)}")
        summary_lines.append(f"{pipe}└── Total Disaster alarms: {stats.get('Disaster', 0)}")
    return "\n".join(summary_lines)

def _enrich_alarms_with_hosts(zabbix_api, alarms, logger):
    # Performs the two-step query to enrich a list of alarms with their hostnames.
    if not alarms:
        return []
    
    # The 'objectid' of a problem/event is the 'triggerid'.
    trigger_ids = [alarm['objectid'] for alarm in alarms]
    logger.info(f"Fetching host details for {len(trigger_ids)} triggers.")
    
    triggers = zabbix_api.get_triggers_by_ids(trigger_ids)
    trigger_map = {trigger['triggerid']: trigger for trigger in triggers}

    for alarm in alarms:
        trigger_id = alarm['objectid']
        if trigger_id in trigger_map:
            alarm['hosts'] = trigger_map[trigger_id].get('hosts', [])
        else:
            alarm['hosts'] = []
    return alarms

def main():
    print("Starting Zabbix Alarm Collector...")

    config = load_config()
    #<incase want excel file to be daynamic from config file, comment above, and uncomment below>
    #jump_servers = dict(config['JumpServers'])
    #sites = list(jump_servers.keys())
    logger = logging.getLogger(config['General']['log_folder'])
    logger.info(f"=================================================")
    logger.info("Configuration loaded.")
    logger.info(f"=================================================")

    # Collect credentials
    ssh_user = config['JumpCredentials'].get('username')
    ssh_password = config['JumpCredentials'].get('password')
    zabbix_user = config['ZabbixCredentials']['username']
    zabbix_pass = config['ZabbixCredentials']['password']

    # Prepare site/jump server info
    jump_servers = dict(config['JumpServers'])
    zabbix_endpoints = dict(config['ZabbixEndpoints'])
    sites = list(jump_servers.keys())

    """
    # Determine time window (Monday logic)
    now = datetime.datetime.now()
    if now.weekday() == 0:  # Monday
        start = now - datetime.timedelta(days=3)  # from Friday to Monday
        logger.info("Today is Monday. Collecting alarms from Friday 06:00 to Monday 06:00.")
        logger.info(f"=================================================")
    else:
        start = now - datetime.timedelta(days=1)
        logger.info(f"Today is {now.strftime('%A')}. Collecting alarms from yesterday 06:00 to today 06:00.")
        logger.info(f"=================================================")
    time_from = int(datetime.datetime.combine(start.date(), datetime.time(6, 0)).timestamp())
    time_till = int(datetime.datetime.combine(now.date(), datetime.time(6, 0)).timestamp())
    logger.info(f"Alarm collection time window: from {datetime.datetime.fromtimestamp(time_from)} to {datetime.datetime.fromtimestamp(time_till)}.")
    logger.info(f"=================================================")

    """
    # flexibility days back collection
    days_back = 90
    now = datetime.datetime.now()
    start = now - datetime.timedelta(days=days_back)
    logger.info(f"Collecting alarms from {days_back} day(s) ago at 06:00 to today at 06:00.")
    logger.info(f"=================================================")

    time_from = int(datetime.datetime.combine(start.date(), datetime.time(6, 0)).timestamp())
    time_till = int(datetime.datetime.combine(now.date(), datetime.time(6, 0)).timestamp())

    logger.info(f"Alarm collection time window: from {datetime.datetime.fromtimestamp(time_from)} to {datetime.datetime.fromtimestamp(time_till)}.")
    logger.info(f"=================================================")
    
    
    # Create Excel report and sheets
    report_generator = ExcelReportGenerator(logger=logger)
    #<incase want excel file to be daynamic from config file, comment above, and uncomment below>
    #report_generator = ExcelReportGenerator(sheet_names=sites, logger=logger)
    report_generator.create_empty_report()
    logger.info(f"=================================================")
    
    summary_stats = {}
    unreachable_sites = []

    for site in sites:
        logger.info(f"Processing site: {site.upper()}")
        jump_ip = jump_servers[site]
        zabbix_api_url = zabbix_endpoints[site]

        # 1. Connect to jump server
        ssh_client = SSHJumpClient(
            hostname=jump_ip,
            username=ssh_user,
            password=ssh_password,
            logger=logger
        )
        if not ssh_client.connect():
            logger.error(f"Could not connect to jump server {jump_ip} for site {site.upper()}. Skipping site.")
            logger.info(f"=================================================")
            unreachable_sites.append(site.upper())
            continue

        # 2. Authenticate to Zabbix API for this site
        zabbix_api = ZabbixAPIClient(
            api_url=zabbix_api_url,
            username=zabbix_user,
            password=zabbix_pass,
            ssh_client=ssh_client,
            logger=logger,
            site_name=site.upper()
        )
        if not zabbix_api.authenticate():
            logger.error(f"Failed Zabbix API login for site {site.upper()}. Skipping site.")
            ssh_client.disconnect()
            unreachable_sites.append(site.upper())
            continue
        """
        # 3. Collect alarms/events for this site
        alarms = zabbix_api.get_current_problems()
        logger.info(f"Collected {len(alarms)} active problems for site {site.upper()}.")
        logger.info(f"Sorting {len(alarms)} active problems for site {site.upper()} by severity and age.")

        if alarms:
            # STEP 2: Get all trigger IDs from the problems. The 'objectid' of a problem is the 'triggerid'.
            trigger_ids = [alarm['objectid'] for alarm in alarms]
            logger.info(f"Fetching host details for {len(trigger_ids)} triggers.")

            # STEP 3: Fetch trigger data, which reliably includes host info.
            triggers = zabbix_api.get_triggers_by_ids(trigger_ids)

            # Create a mapping from triggerid -> trigger object for easy lookup.
            trigger_map = {trigger['triggerid']: trigger for trigger in triggers}

            # STEP 4: Merge the host data back into the original alarm objects.
            for alarm in alarms:
                trigger_id = alarm['objectid']
                if trigger_id in trigger_map:
                    # The 'hosts' array comes from the trigger data.
                    alarm['hosts'] = trigger_map[trigger_id].get('hosts', [])
                else:
                    # Just in case, ensure a 'hosts' key exists.
                    alarm['hosts'] = []
        """
        # 3. Collect, tag, and combine alarms
        all_alarms = {}

        # Get Active Alarms
        logger.info(f"Collecting ACTIVE problems for site {site.upper()}...")
        active_alarms = zabbix_api.get_current_problems()
        active_alarms = _enrich_alarms_with_hosts(zabbix_api, active_alarms, logger)
        for alarm in active_alarms:
            alarm['status'] = 'Active'
            #all_alarms[alarm['eventid']] = alarm
        logger.info(f"Found {len(active_alarms)} active problems.")

        active_event_ids = {alarm['eventid'] for alarm in active_alarms}

        # Get Historical Problems 
        logger.info(f"Collecting HISTORICAL problems for site {site.upper()}")
        historical_alarms_raw = zabbix_api.get_historical_events(time_from=time_from, time_till=time_till)
        historical_alarms_raw = _enrich_alarms_with_hosts(zabbix_api, historical_alarms_raw, logger)
        # Filter out any historical alarms that are still active
        historical_alarms = []
        for alarm in historical_alarms_raw:
            if alarm['eventid'] not in active_event_ids:
                alarm['status'] = 'Problem'
                all_alarms[alarm['eventid']] = alarm
                historical_alarms.append(alarm)
        logger.info(f"Found {len(historical_alarms)} historical problems.")

        # --- Sort each list individually ---
        for alarm_list in [active_alarms, historical_alarms]:
            for alarm in alarm_list:
                alarm['severity_str'] = SEVERITY_MAP.get(str(alarm.get("severity", "")), str(alarm.get("severity", "")))
                alarm['clock_int'] = int(alarm.get("clock", 0))
            alarm_list.sort(key=lambda a: (SEVERITY_SORT_ORDER.get(a['severity_str'], 99), a['clock_int']))

        # --- Combine lists in the desired order ---
        alarms = active_alarms + historical_alarms
        logger.info(f"Total unique alarms for site {site.upper()}: {len(alarms)}")

        """
        # DEBUG: Print the first alarm object to inspect its structure
        if alarms:
            logger.info(f"DEBUG: First alarm object for site {site.upper()}: {alarms[0]}")
        else:
            logger.info(f"DEBUG: No alarms found for site {site.upper()}.")
        
        logger.info(f"Sorting {len(alarms)} alarms for site {site.upper()} by severity and age.")

        # DEBUG: Print the first alarm object to inspect its structure
        if alarms:
            logger.info(f"DEBUG: First alarm object for site {site.upper()}: {alarms[0]}")
        else:
            logger.info(f"DEBUG: No alarms found for site {site.upper()}.")

        # Sort alarms by severity and age
        for alarm in alarms:
            alarm['severity_str'] = SEVERITY_MAP.get(str(alarm.get("severity", "")), str(alarm.get("severity", "")))
            alarm['clock_int'] = int(alarm.get("clock", 0))
        alarms.sort(key=lambda a: (SEVERITY_SORT_ORDER.get(a['severity_str'], 99), a['clock_int']))
        """
        report_generator.append_alarms(site, alarms)
        ssh_client.disconnect()

        # Collect stats for summary
        stats = {"total": len(alarms), "Information": 0, "Warning": 0, "Average": 0, "High": 0, "Disaster": 0}
        for alarm in alarms:
            sev = alarm.get("severity")
            if sev == "1":
                stats["Information"] += 1
            elif sev == "2":
                stats["Warning"] += 1
            elif sev == "3":
                stats["Average"] += 1
            elif sev == "4":
                stats["High"] += 1
            elif sev == "5":
                stats["Disaster"] += 1
        summary_stats[site] = stats
        logger.info(f"=================================================")
        
    # Save Excel report
    output_path = report_generator.save()

    #setup PDF conversion
    excel_path = output_path  # Path to your saved Excel file
    pdf_folder = os.path.join(os.path.dirname(os.path.dirname(excel_path)), "Report-PDF")
    os.makedirs(pdf_folder, exist_ok=True)
    pdf_path = os.path.join(pdf_folder, os.path.splitext(os.path.basename(excel_path))[0] + ".pdf")
    excel_to_pdf(excel_path, pdf_path)
    logger.info(f"=================================================")
    logger.info(f"PDF report saved to {pdf_path}")

    # Existing PDF path (without logo)
    pdf_path = os.path.join(pdf_folder, os.path.splitext(os.path.basename(excel_path))[0] + ".pdf")
    # New folder for PDFs with logo
    pdf_logo_folder = os.path.join(BASE_DIR, "Report-PDF-Logo")
    os.makedirs(pdf_logo_folder, exist_ok=True)
    # Path for PDF with logo
    pdf_logo_path = os.path.join(pdf_logo_folder, os.path.basename(pdf_path))
    # Add logo to the PDF and save to new location
    logo_path = os.path.join(BASE_DIR, "icons", "NEC-logo.png")
    add_logo_footer(pdf_path, logo_path, logger=logger, logo_width=LOGO_WIDTH, logo_height=LOGO_HEIGHT, margin_bottom=LOGO_MARGIN_BOTTOM, margin_left=LOGO_MARGIN_LEFT, output_path=pdf_logo_path)    
    
    # Prepare HTML email body with Consolas font
    email_body = f"""
    <html>
        <body>
            <pre style="font-family: Consolas, monospace; font-size: 14px;">
Dear COE Team,

Hope this email finds you well!

Please find the attached zabbix alarm report, below summary of collected alarms:
{build_summary_text(sites, summary_stats)}



Sincerely,
ZabbExcel v1.0
NEC | GCC Branch
            </pre>
        </body>
    </html>
"""
    
    # Send email with attachment, remove the comment to enable email functionality
    smtp_server = config['Email']['smtp_server']
    smtp_port = config['Email']['smtp_port']
    smtp_user = config['Email']['smtp_user']
    smtp_password = config['Email']['smtp_password']
    email_sender = config['Email']['sender']
    email_recipients = [r.strip() for r in config['Email']['recipients'].split(",")]
    email_subject = "ZabbExcel / Telco Cloud Daily Monitoring / Incident Report - " + datetime.datetime.now().strftime("%d-%m-%Y")
    email_status = "not sent"
    """
    email_sent = send_email_with_attachments(
        smtp_server=smtp_server,
        smtp_port=smtp_port,
        smtp_user=smtp_user,
        smtp_password=smtp_password,
        sender=email_sender,
        recipients=email_recipients,
        subject=email_subject,
        body=email_body,
        attachment_paths=[pdf_logo_path, output_path],
        logger=logger
    )
    if email_sent:
        logger.info("Email sent successfully.")
        email_status = "sent"
    else:
        logger.warning("Failed to send email.")
        email_status = "failed"
    """
    total_sites = len(sites)
    total_alarms = sum(stats["total"] for stats in summary_stats.values())
    
    if unreachable_sites:
        unreachable_msg = "Unreachable sites:  [" + ", ".join(unreachable_sites)+"]"
        logger.warning(unreachable_msg)
    else:
        logger.info("All sites are reachable.")

    logger.info(
        f"Processed {total_sites} sites, collected {total_alarms} alarms. "
        f"Email was {email_status}."
    )

    logger.info(f"=================================================")
    print("Summary of Collected Alarms:")
    print(build_summary_text(sites, summary_stats))

if __name__ == "__main__":
    main()