import os

# This will always resolve to the project root, no matter where you run from
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
REPORTS_DIR = os.path.join(BASE_DIR, 'Reports-Excel')
LOGS_DIR = os.path.join(BASE_DIR, 'LOGs')