import os
import win32com.client

def excel_to_pdf(excel_path, pdf_path):
    excel_path = os.path.abspath(excel_path)
    pdf_path = os.path.abspath(pdf_path)

    # Basic COM call (safe for environments missing gencache)
    excel = win32com.client.DispatchEx("Excel.Application")
    wb = None

    try:
        wb = excel.Workbooks.Open(excel_path)
        for sheet in wb.Sheets:
            page_setup = sheet.PageSetup

            # Set orientation to Landscape
            page_setup.Orientation = 2  # 2 = xlLandscape, 1 = xlPortrait

            # A4 paper size, 9 = xlPaperA4
            page_setup.PaperSize = 9 

            # Set margins to Narrow, Units are in inches
            page_setup.TopMargin = excel.InchesToPoints(0.25)
            page_setup.BottomMargin = excel.InchesToPoints(0.5)
            page_setup.LeftMargin = excel.InchesToPoints(0.25)
            page_setup.RightMargin = excel.InchesToPoints(0.19)

            # Optional: fit to 1 page wide
            page_setup.Zoom = False
            page_setup.FitToPagesWide = 1
            page_setup.FitToPagesTall = False
        wb.ExportAsFixedFormat(Type=0, Filename=pdf_path)
    finally:
        if wb:
            wb.Close(False)
        try:
            excel.Quit()
        except:
            pass