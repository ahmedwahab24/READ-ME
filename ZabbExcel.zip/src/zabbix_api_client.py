import json

class ZabbixAPIClient:
    def __init__(self, api_url, username, password, ssh_client, logger=None, site_name=None):
        self.api_url = api_url
        self.username = username
        self.password = password
        self.ssh_client = ssh_client
        self.logger = logger
        self.session = None
        self.site_name = site_name

    def _run_api_request(self, payload, method_name):
        """Helper to run a curl command over SSH and parse the JSON response."""
        if not self.session:
            if self.logger:
                self.logger.error("No API session. Authenticate first.")
            return []

        payload["auth"] = self.session
        curl_cmd = (
            f"curl -s -X POST -H \"Content-Type: application/json-rpc\" "
            f"-d '{json.dumps(payload)}' {self.api_url} --insecure"
        )
        out, err, status = self.ssh_client.run_curl(curl_cmd)

        if status == 0:
            if self.logger:
                self.logger.info(f"Executed {method_name} command on {self.site_name}")
            try:
                return json.loads(out).get("result", [])
            except (json.JSONDecodeError, AttributeError) as e:
                if self.logger:
                    self.logger.error(f"Failed to parse {method_name} response: {e}")
        else:
            if self.logger:
                self.logger.error(f"{method_name} failed: {err}")
        return []

    def authenticate(self):
        login_payload = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "user": self.username,
                "password": self.password
            },
            "id": 1
        }
        curl_cmd = (
            f"curl -s -X POST -H \"Content-Type: application/json-rpc\" "
            f"-d '{json.dumps(login_payload)}' {self.api_url} --insecure"
        )
        out, err, status = self.ssh_client.run_curl(curl_cmd)
        if status == 0:
            try:
                resp = json.loads(out)
                self.session = resp.get("result")
                if self.session:
                    if self.logger:
                        self.logger.info(f"Executed Zabbix API token request command on {self.site_name}")
                        self.logger.info(f"Authenticated to Zabbix API for {self.site_name}")
                    return True
                else:
                    error_message = resp.get('error', 'Unknown error')
                    if self.logger:
                        self.logger.error(f"Authentication failed: {error_message}")
            except (json.JSONDecodeError, AttributeError) as e:
                if self.logger:
                    self.logger.error(f"Failed to parse login response: {e}")
        else:
            if self.logger:
                self.logger.error(f"Login failed: {err}")
        return False

    def get_current_problems(self):
        """Gets all currently active problems (unresolved)."""
        payload = {
            "jsonrpc": "2.0",
            "method": "problem.get",
            "params": {
                "output": "extend",
                "sortfield": ["eventid"],
                "sortorder": "DESC"
            },
            "id": 1
        }
        return self._run_api_request(payload, "problem.get")

    def get_historical_events(self, time_from, time_till):
        """Gets historical problem events within a time range."""
        payload = {
            "jsonrpc": "2.0",
            "method": "event.get",
            "params": {
                "output": "extend",
                "time_from": time_from,
                "time_till": time_till,
                "object": 0,  # Trigger-based events
                "value": 1,   # Problem events
                "sortfield": ["clock", "eventid"],
                "sortorder": "DESC"
            },
            "id": 1
        }
        return self._run_api_request(payload, "event.get")

    def get_triggers_by_ids(self, trigger_ids):
        """Gets trigger information, including hostname, for a list of trigger IDs."""
        payload = {
            "jsonrpc": "2.0",
            "method": "trigger.get",
            "params": {
                "output": ["triggerid"],
                "triggerids": trigger_ids,
                "selectHosts": ["host", "name"]
            },
            "id": 1
        }
        return self._run_api_request(payload, "trigger.get")